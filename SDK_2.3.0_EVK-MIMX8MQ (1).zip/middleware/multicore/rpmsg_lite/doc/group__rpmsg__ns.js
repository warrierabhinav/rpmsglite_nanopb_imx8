var group__rpmsg__ns =
[
    [ "rpmsg_ns_callback_data", "group__rpmsg__ns.html#structrpmsg__ns__callback__data", [
      [ "cb", "group__rpmsg__ns.html#a02e5cbf5390e2dff441590b2320a8dae", null ],
      [ "user_data", "group__rpmsg__ns.html#ac8005ef661e83b4e1194e5a216879271", null ]
    ] ],
    [ "rpmsg_ns_handle", "group__rpmsg__ns.html#structrpmsg__ns__context", [
      [ "ept", "group__rpmsg__ns.html#a84d6877d4fc4f533c84004a48c304644", null ],
      [ "cb_ctxt", "group__rpmsg__ns.html#a89db4bf8601f3786b1c7076472c4c749", null ]
    ] ],
    [ "rpmsg_ns_static_context", "group__rpmsg__ns.html#structrpmsg__ns__static__context__container", [
      [ "ept_ctxt", "group__rpmsg__ns.html#adb9124f3ad2e764e3d3266e953034e1d", null ],
      [ "cb_ctxt", "group__rpmsg__ns.html#a8bfe9304a786baee4a6043e84d7882a4", null ],
      [ "ns_ctxt", "group__rpmsg__ns.html#aa1a0ab21719083266c19c8102c5445c7", null ]
    ] ],
    [ "rpmsg_ns_new_ept_cb", "group__rpmsg__ns.html#ga9c275f7b254e1e3b3a704f17137bd440", null ],
    [ "rpmsg_ns_bind", "group__rpmsg__ns.html#gab2e44f497543e00f358bba04566b5e36", null ],
    [ "rpmsg_ns_unbind", "group__rpmsg__ns.html#ga359637fe5894c438c7cbd795f28ecd31", null ],
    [ "rpmsg_ns_announce", "group__rpmsg__ns.html#ga50008dfe70bc440c7803bd44fc1bdc2a", null ]
];