var searchData=
[
  ['ept',['ept',['../group__rpmsg__lite.html#a4cbac751c0f2b20768136c31610906f8',1,'rpmsg_lite_ept_static_context']]]
];
