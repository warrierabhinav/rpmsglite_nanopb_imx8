var searchData=
[
  ['addr',['addr',['../group__rpmsg__lite.html#a28c0e9a7a70fbc58a497f2d3fac96f70',1,'rpmsg_lite_endpoint']]]
];
