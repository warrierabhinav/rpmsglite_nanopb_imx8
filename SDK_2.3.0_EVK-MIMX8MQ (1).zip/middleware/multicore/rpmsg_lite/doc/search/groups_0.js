var searchData=
[
  ['rpmsg_2dlite_20core_20component',['RPMsg-Lite Core Component',['../group__rpmsg__lite.html',1,'']]],
  ['rpmsg_20name_20service_20component',['RPMsg Name Service Component',['../group__rpmsg__ns.html',1,'']]],
  ['rpmsg_20queue_20component',['RPMsg Queue Component',['../group__rpmsg__queue.html',1,'']]]
];
