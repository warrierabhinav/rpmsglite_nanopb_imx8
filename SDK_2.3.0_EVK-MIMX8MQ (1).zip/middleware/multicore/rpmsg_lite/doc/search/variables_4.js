var searchData=
[
  ['rfu',['rfu',['../group__rpmsg__lite.html#adae527c972c102f433354448d3ab05a7',1,'rpmsg_lite_endpoint']]],
  ['rl_5fendpoints',['rl_endpoints',['../group__rpmsg__lite.html#a50ba617e06016bb1ca0d1a4dd7d0ac65',1,'rpmsg_lite_instance']]],
  ['rvq',['rvq',['../group__rpmsg__lite.html#a3bf53c7a9d4a0fbfd6ec924a19f7e7b8',1,'rpmsg_lite_instance']]],
  ['rx_5fcb',['rx_cb',['../group__rpmsg__lite.html#a457c132df214a78150ae4525b6100700',1,'rpmsg_lite_endpoint']]],
  ['rx_5fcb_5fdata',['rx_cb_data',['../group__rpmsg__lite.html#a30e868937950060fbcce818a2bc35db8',1,'rpmsg_lite_endpoint']]]
];
