var searchData=
[
  ['link_5fstate',['link_state',['../group__rpmsg__lite.html#ab4fb1dac3c1924deba08c38ee6cb828b',1,'rpmsg_lite_instance']]],
  ['lock',['lock',['../group__rpmsg__lite.html#ab4f1d8d26a8fed002f3e113cb988b1a8',1,'rpmsg_lite_instance']]]
];
