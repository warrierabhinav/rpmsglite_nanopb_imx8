var group__rpmsg__queue =
[
    [ "rpmsg_queue_handle", "group__rpmsg__queue.html#gaa6d197ceb3befc71d29f7b4a969d3d3e", null ],
    [ "rpmsg_queue_rx_cb", "group__rpmsg__queue.html#ga5333db7bb4b09c87ae4ad9c75dc610a5", null ],
    [ "rpmsg_queue_create", "group__rpmsg__queue.html#gaf2b13335342ec06d8c264bbb6e27c88f", null ],
    [ "rpmsg_queue_destroy", "group__rpmsg__queue.html#ga90d72e18752f3dad3cf9cab348186e6b", null ],
    [ "rpmsg_queue_recv", "group__rpmsg__queue.html#gac9e320318d2f2ee5e7b1776a4fadfd08", null ],
    [ "rpmsg_queue_recv_nocopy", "group__rpmsg__queue.html#ga119b346b47ed2fddee31a80de73bfa11", null ],
    [ "rpmsg_queue_nocopy_free", "group__rpmsg__queue.html#gac31e8495ea7d563a92c2e03acb03e464", null ]
];