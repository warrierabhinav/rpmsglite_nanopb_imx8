var modules =
[
    [ "RPMsg-Lite Core Component", "group__rpmsg__lite.html", "group__rpmsg__lite" ],
    [ "RPMsg Queue Component", "group__rpmsg__queue.html", "group__rpmsg__queue" ],
    [ "RPMsg Name Service Component", "group__rpmsg__ns.html", "group__rpmsg__ns" ]
];